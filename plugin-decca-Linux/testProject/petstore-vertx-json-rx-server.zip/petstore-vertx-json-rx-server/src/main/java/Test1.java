import io.swagger.server.api.verticle.PetApiVerticle;
import io.vertx.core.eventbus.impl.clustered.ClusteredMessage;
import io.vertx.core.eventbus.impl.codecs.JsonObjectMessageCodec;

public class Test1 {
	public static void main(String[] args) {
		new PetApiVerticle();
//		new io.vertx.core.json.JsonObject(new io.vertx.core.buffer.impl.BufferImpl());
		new ClusteredMessage(null, "test", null, null, args, new JsonObjectMessageCodec(), false, null).body();
	}
}
